Double Reset Detector
=====================

Library to detect a double reset, using ESP8266 RTC Memory

VERSION:	1.0.0

PURPOSE:	Detects a double reset so that an alternative start-up mode can
be used. One example use is to allow re-configuration of a device's wifi.

LICENCE:	MIT
